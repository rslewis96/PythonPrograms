"""
Filename: Main.py
Author: Ryan Lewis
Date: 2026-01-13
Version: 1.0
Description: Main file for webscraping Personal Weather Station data from weathercloud.net.

Note: Code was created PyCharm using Python version 3.13

      selenium webdriver was used over BeautifulSoup because of the need to capture the Javascript and not the
      HTML for items that are dynamic like temp, wind speed, etc.
"""

#Libraries
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from datetime import datetime
import time
import csv

driver = webdriver.Chrome()

#Edit the variable "weatherstation" below with your variable
weatherstation = "d5899257076"
url = f"https://app.weathercloud.net/{weatherstation}#current" #modify the current to add the wind data.

# Define the CSV header (column names)
HEADER = ['Timestamp', 'Temperature', 'Humidity', 'Humidity', 'Humidity', 'Pressure', 'Dewpoint', 'Wind Chill',
          'Heat Index', 'Rain', 'Rain Rate']
FILENAME = 'sensor_data.csv'



#run indefinitely
try:
    with open(FILENAME, mode='a', newline='') as csvfile:
        writer = csv.writer(csvfile)
        writer.writerow(HEADER)

        while True:
            timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            print(f"\n[{timestamp}] Checking Weather Station...")

            try:
                driver.get(url)

                #Wait for page to load first
                wait = WebDriverWait(driver, 15)


                #Extract Data
                station_name = driver.find_element(By.CSS_SELECTOR, "#device-view-title h1").text.strip()
                temp_element = wait.until(EC.presence_of_element_located((By.CLASS_NAME, "temp-value-text")))
                current_temp = temp_element.text.strip()
                current_hum = driver.find_element(By.CLASS_NAME, "hum-value-text").text.strip()
                current_bar = driver.find_element(By.CLASS_NAME, "bar-value-text").text.strip()
                current_dewpoint = driver.find_element(By.CLASS_NAME, "dew-value-text").text.strip()
                current_windchill = driver.find_element(By.CLASS_NAME, "chill-value-text").text.strip()
                current_heatindex = driver.find_element(By.CLASS_NAME, "heat-value-text").text.strip()
                current_rain = driver.find_element(By.CLASS_NAME, "rain-value-text").text.strip()
                current_rainrate = driver.find_element(By.CLASS_NAME, "rainrate-value-text").text.strip()

                #Print Output
                print(f"Station: {station_name}")
                print(f"Temp: {current_temp} | Humidity: {current_hum} | Pressure: {current_bar} | Dewpoint: {current_dewpoint} | Wind Chill: {current_windchill} | Heat Index: {current_heatindex} | Rain: {current_rain} | Rain Rate: {current_rainrate}")

                data_row = [timestamp, current_temp, current_hum, current_bar, current_dewpoint, current_windchill, current_heatindex, current_rain, current_rainrate]
                writer.writerow(data_row)

                #Flush the file buffer to ensure data is written to disk immediately
                csvfile.flush()

            except Exception as e:
                print(f"Error during scrape: {e}")
                print("Will try again in the next cycle.")

            #Sleep for 5 minutes (300 seconds)
            print("Sleeping for 5 minutes...")
            time.sleep(300)

finally:
    # ensures the browser closes
    driver.quit()